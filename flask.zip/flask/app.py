from flask import Flask, request, render_template
import dbconn as lg
import math


app = Flask(__name__)
import pickle

model = pickle.load(open('model.pkl','rb'))

@app.route("/")
def index():
    return render_template("login.html")

@app.route('/auth', methods=['POST'])
def auth():
    print('123')
    user     = request.form['username']
    password = request.form['password']

    # check if the username and password are valid
    usename ,pswd = lg.getcredentials()
    if user in usename:
      if password  in pswd:
         return render_template('index.html')
    else:
        # if the username and password are not valid, redirect back to the login page
        return render_template('login.html', error='Invalid username or password')
  

@app.route("/predict", methods=['post'])
def pred():
    features = [float(i) 
                for i in 
                (request.form.values())]
    pred = model.predict([features])
    pred = math.ceil(pred[0])
    return render_template("success.html", data=pred)



if __name__=="__main__":
    app.run(debug=True)
    

    

    
    
    
    
    