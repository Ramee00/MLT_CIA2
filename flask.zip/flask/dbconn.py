import pymysql as pms

conn = pms.connect(host="localhost", 
                   port=3306,
                   user="root",
                   password="ramee2003",
                   db="login")
cursor = conn.cursor()


def getcredentials():
    username = []
    password = []
    cursor.execute("SELECT * FROM login")
    result = cursor.fetchall()
    for i in result:
        username.append(i[0])
        password.append(i[1])
        
    return username, password


#%%
'''
cur.execute("select * from login")
#%%
output = cur.fetchone()
print(output)

#%%
import pandas as pd
sql = "select * from login"
df = pd.read_sql(sql, conn)
#%%
<html>

<body>

<form action="/predict" method="Post">
<input type="text" name="exp" placeholder="Yrs of Exp"/>
<br />
<input type="text" name="test" placeholder="test score" />
<br />
<input type="text" name="int" placeholder="Inte score"/>
<br />
<input type="submit" />
</form>

{{data}}
</body>

</html>
<button type="submit" >Login</button>  '''






















