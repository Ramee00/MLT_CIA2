#%%
'''
BMI Index :

0 - Extremely Weak

1 - Weak

2 - Normal

3 - Overweight

4 - Obesity

5 - Extreme Obesity
<input type="submit" />
'''
#%%
import pandas as pd
import numpy as np

data=pd.read_csv("bmi.csv")

data=pd.get_dummies(data)

x=data.iloc[:,[0,1,3]].values
y=data.iloc[:,2].values

from sklearn.linear_model import LinearRegression
regression = LinearRegression()

regression.fit(x,y)

print(np.ceil(regression.predict([[164,71,1]])))
#%%
import pickle

pickle.dump(regression,open('model.pkl','wb'))


